package com.l4yn3.microserviceseclab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiceSeclabApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceSeclabApplication.class, args);
	}

}
