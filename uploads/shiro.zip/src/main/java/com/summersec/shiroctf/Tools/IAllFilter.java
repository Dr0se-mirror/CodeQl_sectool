package com.summersec.shiroctf.Tools;

public interface IAllFilter {
    String filter(String param);
}
