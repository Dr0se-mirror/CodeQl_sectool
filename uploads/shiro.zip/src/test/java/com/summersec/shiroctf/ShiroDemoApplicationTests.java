package com.summersec.shiroctf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiroDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
